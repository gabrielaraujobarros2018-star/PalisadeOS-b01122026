# System Lattice FS (SLFS)

System Lattice FS (SLFS) is NeoKern’s unified, POSIX-compliant system configuration and state interface.  
It replaces traditional registry-style designs with a transparent, filesystem-native model that is readable, writable, scriptable, and safe by default.

SLFS is **not** a registry clone.  
It is a system-state lattice exposed as plain files.

---

## Design Goals

- POSIX-compliant and shell-friendly  
- Text-based (UTF-8), no opaque binary blobs  
- Safe to inspect, modify, and version  
- Kernel, GUI, and hardware aware  
- Atomic and rollback-capable  
- Zero dependency on proprietary concepts  

Every value in SLFS can be inspected with standard tools and modified using standard POSIX semantics.

---

## Core Concepts

### Domains
A domain represents a logical system area (kernel, GUI, network, security, etc.).  
Domains define *what exists* in the system, not just its current values.

### State
State files represent **live, mutable system values**.  
Reading returns real-time data.  
Writing triggers controlled kernel or subsystem handlers.

State resets on reboot unless explicitly promoted to policy.

### Policy
Policy files represent **persistent configuration**.  
They are parsed at boot and can be reloaded at runtime.  
All policy files are plain text and human-readable.

### Runtime
Runtime data represents **ephemeral session information** such as process lifetimes, initialization stages, and temporary system context.

Runtime data never persists across reboots.

### Hardware Control
Hardware exposure in SLFS allows safe, structured interaction with drivers.  
Values map directly to kernel driver interfaces rather than configuration guesses.

### GUI Control Plane
GUI behavior is controlled through SLFS instead of hidden APIs.  
This enables shell-level automation, debugging, and live tuning of the graphical environment.

### Security Visibility
Security settings and audit data are observable, inspectable, and traceable.  
Nothing critical is hidden behind binary databases or undocumented formats.

---

## Atomic Transactions

SLFS supports **transactional configuration changes**.

Instead of writing directly to live configuration:
1. Changes are staged in a transaction
2. Transactions are validated
3. Changes are atomically applied
4. Automatic rollback occurs if a failure is detected

This guarantees:
- No partial system corruption
- Safe experimentation
- Boot-time recovery without manual repair

---

## Safety Model

- All writable nodes enforce permission checks
- Invalid writes are rejected before execution
- Kernel panic paths are isolated from configuration
- No single write can permanently brick the system

SLFS is designed so that **failure is reversible by default**.

---

## Why SLFS Exists

Traditional registries:
- Hide system behavior
- Encourage undocumented keys
- Corrupt easily
- Break scripting and automation

SLFS instead:
- Encourages understanding
- Enables automation
- Preserves system integrity
- Scales cleanly from kernel to GUI

---

## Intended Usage

SLFS is meant to be used by:
- Shell tools
- System utilities
- GUI control panels
- Diagnostics and inspection tools
- Snapshot and recovery systems

It is not intended to be edited by hex editors, binary tools, or proprietary software.

---

## Philosophy

> Configuration is data, not magic.

SLFS treats system behavior as **observable, explainable, and reversible**.  
It aligns with NeoKern’s goal of being transparent, debuggable, and resilient by design.

---

## Status

SLFS is a core NeoKern subsystem and evolves alongside the kernel and GUI stack.  
Backward compatibility is preserved through explicit versioning and migration rules.

---

## License

SLFS follows the same license as NeoKern.  
All specifications are open and implementation-agnostic.